-- ============================================================
--  CONTROLE INTERNO — SAAETRI
--  Script de criação do banco de dados no Supabase
--  Execute este script no SQL Editor do seu projeto Supabase
-- ============================================================

-- ── 1. EXTENSÕES ─────────────────────────────────────────────
create extension if not exists "uuid-ossp";

-- ── 2. TABELA: profiles ───────────────────────────────────────
-- Armazena dados extras dos usuários (criada automaticamente
-- quando um usuário se cadastra via trigger abaixo)

create table if not exists public.profiles (
    id          uuid primary key references auth.users(id) on delete cascade,
    full_name   text,
    created_at  timestamptz default now()
);

alter table public.profiles enable row level security;

create policy "Usuário lê seu próprio perfil"
    on public.profiles for select
    using (auth.uid() = id);

create policy "Usuário atualiza seu próprio perfil"
    on public.profiles for update
    using (auth.uid() = id);

-- Trigger: cria perfil automaticamente ao registrar usuário
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer as $$
begin
    insert into public.profiles (id, full_name)
    values (
        new.id,
        new.raw_user_meta_data->>'full_name'
    );
    return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
    after insert on auth.users
    for each row execute procedure public.handle_new_user();


-- ── 3. TABELA: analises ───────────────────────────────────────
-- Cada linha é uma análise de habilitação de fornecedor

create table if not exists public.analises (
    id              uuid primary key default uuid_generate_v4(),
    user_id         uuid not null references auth.users(id) on delete cascade,

    -- Dados do processo
    numero_processo text,
    modalidade      text,
    objeto          text,
    empresa         text,
    cnpj            text,
    data_analise    date,

    -- Resultado
    parecer         text check (parecer in ('regular', 'ressalvas', 'irregular', null)),
    observacoes     text,

    -- Checklist (armazenado como JSONB)
    -- Estrutura: { "fase1": { "item_id": true/false, ... }, "fase2": { ... }, ... }
    checklist       jsonb default '{}',

    -- Justificativas selecionadas (array de objetos)
    justificativas  jsonb default '[]',

    -- Metadados
    created_at      timestamptz default now(),
    updated_at      timestamptz default now()
);

-- Índices
create index if not exists analises_user_id_idx       on public.analises (user_id);
create index if not exists analises_cnpj_idx          on public.analises (cnpj);
create index if not exists analises_data_analise_idx  on public.analises (data_analise);
create index if not exists analises_parecer_idx       on public.analises (parecer);

-- RLS
alter table public.analises enable row level security;

create policy "Usuário lê suas análises"
    on public.analises for select
    using (auth.uid() = user_id);

create policy "Usuário insere suas análises"
    on public.analises for insert
    with check (auth.uid() = user_id);

create policy "Usuário atualiza suas análises"
    on public.analises for update
    using (auth.uid() = user_id);

create policy "Usuário deleta suas análises"
    on public.analises for delete
    using (auth.uid() = user_id);

-- Trigger: atualiza updated_at automaticamente
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
    new.updated_at = now();
    return new;
end;
$$;

drop trigger if exists analises_updated_at on public.analises;
create trigger analises_updated_at
    before update on public.analises
    for each row execute procedure public.set_updated_at();


-- ── 4. VIEW: resumo_analises ──────────────────────────────────
-- View auxiliar com contagem de itens do checklist por análise

create or replace view public.resumo_analises as
select
    a.id,
    a.user_id,
    a.numero_processo,
    a.modalidade,
    a.objeto,
    a.empresa,
    a.cnpj,
    a.data_analise,
    a.parecer,
    a.created_at,
    a.updated_at
from public.analises a;

-- ── FIM DO SCRIPT ─────────────────────────────────────────────
